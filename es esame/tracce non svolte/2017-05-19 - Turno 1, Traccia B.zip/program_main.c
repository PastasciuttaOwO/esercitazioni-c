//Autore: Vincenzo Silvano - Turno 1 Traccia B
//N.B. nella traccia c'� un errore, il vettore e' di dimensione N

#include <stdio.h>

#define DIM 100
int conta_lettera_riga(char matrice[][DIM],int colonne,char vettore[],int riga_iesima);
void Bubble_sort_decrescente(int vettore[],int lunghezza);

int main()
{
	char mat[DIM][DIM];
	int r;
	int c;

	char vett[DIM];
	int occorrenze_vett[DIM];
	int vett_finale[DIM];

	//file pointer
	FILE *fpIN;
	FILE *fpOUT;

	printf("Autore: Vincenzo Silvano - Turno 1 Traccia B\n\n");

	fpIN=fopen("input.txt","r");

	if(fpIN!=NULL)
	{
	    //lettura righe e colonne da file
	    fscanf(fpIN,"%d",&r);
	    fscanf(fpIN,"%d\n\n",&c); //in questo modo prendo dal file anche i due INVIO (e li "butto")

	    //con questa tecnica evito gli spazi e lo \n e scrivo i char nel vettore
	    for(int i=0;i<r;i++)
            for(int j=0;j<c;j++)
            {
                if(j==c-1)
                    fscanf(fpIN,"%c\n",&mat[i][j]);
                else
                    fscanf(fpIN,"%c ",&mat[i][j]);
            }

        printf("La matrice letta da file, di %d righe e %d colonne, e' la seguente:\n",r,c);
        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
                printf("%3c",mat[i][j]);
            printf("\n");
        }

        //lettura da file del vettore
        fscanf(fpIN,"\n"); //per ignorare la linea tra matrice e vettore nel file

        for(int i=0;i<r;i++)
        {
            if(i==r-1)
                    fscanf(fpIN,"%c\n",&vett[i]);
                else
                    fscanf(fpIN,"%c ",&vett[i]);
        }

        fclose(fpIN);

        //stampa del vettore
        printf("\n\nIl vettore di caratteri di dimensione %d e' il seguente:\n",r);
        for(int i=0;i<r;i++)
            printf("%3c",vett[i]);

        for(int i=0;i<r;i++)
            occorrenze_vett[i]=conta_lettera_riga(mat,c,vett,i);

        printf("\n\nLe occorrenze dei caratteri del vettore precedente nelle rispettive righe:\n");
        for(int i=0;i<r;i++)
            printf("Il carattere %c e' presente %d volte nella riga %d\n",vett[i],occorrenze_vett[i],i+1);
        //N.B. SOLO PER LA STAMPA ho usato una notazione degli indici che vanno da 1 a n e non da 0 a n-1

        //Trasformo il vettore delle occorrenze con la moltiplicazione chiesta da compito

        for(int i=0;i<r;i++)
            vett_finale[i]=0;
        //sto inizializzando il vettore che conterr� i valori corretti

        for(int i=0;i<r;i++)
            for(int j=0;j<c;j++)
                if(mat[i][j]==vett[i])
                {
                    vett_finale[i]+=occorrenze_vett[i]*j;
                }

        printf("\n\nIl vettore delle occorenze con le moltiplicazione chieste da compito e' il seguente:\n");
        for(int i=0;i<r;i++)
            printf("%3d",vett_finale[i]);

        //sottoprogramma che ordina il vettore di int
        Bubble_sort_decrescente(vett_finale,r);

        printf("\n\nIl vettore ordinato in decrescenza e':\n");
        for(int i=0;i<r;i++)
            printf("%3d",vett_finale[i]);

        fpOUT=fopen("output.bin","w");

        if(fpOUT!=NULL)
        {
            fwrite(vett_finale,sizeof(int),r,fpOUT);
            printf("\n\nFile \"output.bin\ correttamente creato...");
            fclose(fpOUT);
        }
        else
            printf("Errore nella creazione di \"output.bin\...");
	}
	else
        printf("File \"input.txt\" non trovato...");
}

int conta_lettera_riga(char matrice[][DIM],int colonne,char vettore[],int riga_iesima)
{
    int cont=0;

    for(int j=0;j<colonne;j++)
        if(matrice[riga_iesima][j]==vettore[riga_iesima])
            cont++;
    return cont;
}

void Bubble_sort_decrescente(int vettore[],int lunghezza)
{
    int k=lunghezza-1;
    int scambio=1;
    int tmp;

    while(k>0&&scambio==1)
    {
        scambio=0;

        for(int i=0;i<k;i++)
        {
            if(vettore[i]<vettore[i+1])
            {
                tmp=vettore[i];
                vettore[i]=vettore[i+1];
                vettore[i+1]=tmp;
                scambio=1;
            }
        }
    }
}