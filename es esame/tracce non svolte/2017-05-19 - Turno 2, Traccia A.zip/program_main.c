//Autore: Vincenzo Silvano - Turno 2 Traccia A
#include <stdio.h>

#define DIM 100

int occorrenze_caratteri(char matrice[][DIM],int colonne,int riga_fissata,char carattere_cercato);
void Bubble_sort(char vett[],int vett_occorrenze[],int dimensione);

int main()
{
    char mat[DIM][DIM];
    int r;
    int c;

    char vett[DIM];
    int dimensione;
    int vett_occorrenze[DIM];
    char stringa_finale[DIM]; //siccome contiene il doppio dei caratteri dei vettori precedenti

    FILE *fpIN;
    FILE *fpOUT;

    printf("Autore: Vincenzo Silvano - Turno 2 Traccia A\n\n");

    fpIN=fopen("input.txt","r");

    if(fpIN!=NULL)
    {
        fscanf(fpIN,"%d",&r);
        fscanf(fpIN,"%d",&c);
        fscanf(fpIN,"%d\n\n",&dimensione); //gli \n\n servono per leggersi anche i due new line

        for(int i=0;i<r;i++) //con questo for leggo la matrice di caratteri ignorando \n e ' '
            for(int j=0;j<c;j++)
            {
                if(j==c-1)
                    fscanf(fpIN,"%c\n",&mat[i][j]);
                else
                    fscanf(fpIN,"%c ",&mat[i][j]);
            }

        printf("La matrice letta da file ha %d righe e %d colonne ed e' la seguente:\n",r,c);
        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
                printf("%3c",mat[i][j]);
            printf("\n");
        }

        fscanf(fpIN,"\n"); //per eludere lo spazio tra la matrice e il primo vettore

        for(int i=0;i<dimensione;i++)
        {
            if(i==dimensione-1)
                fscanf(fpIN,"%c\n",&vett[i]);
            else
                fscanf(fpIN,"%c ",&vett[i]);
        }

        fclose(fpIN);

        printf("\n\nIl vettore letto da file ha %d elementi ed e' il seguente:\n",dimensione);
        for(int i=0;i<dimensione;i++)
            printf("%3c",vett[i]);

        //inizializzazione del vett_occorrenze
        for(int i=0;i<dimensione;i++)
            vett_occorrenze[i]=0;

        for(int i=0;i<r;i++) //cos� analizzo ogni riga con la funzione occorrenze_caratteri
            for(int j=0;j<dimensione;j++)
                vett_occorrenze[j]+=occorrenze_caratteri(mat,c,i,vett[j]);

        //stampa del vettore delle occorrenze
        printf("\n\nIl vettore delle occorrenze con il carattere associato e':\n");
        for(int i=0;i<dimensione;i++)
            printf("Il carattere %c e' presente %d volte\n",vett[i],vett_occorrenze[i]);

        //ordinamento dei due vettori (vett per i caratteri e vett_occorrenze per le occorrenze)
        //passo entrambi i vettori, in modo da poter ottenere il cambiamento su entrambi contemporaneamente
        Bubble_sort(vett,vett_occorrenze,dimensione);

        printf("Come da richiesta d'esame, ecco la stringa ordinata con corrispondeza carattere - occorrenza:\n");
        for(int i=0;i<dimensione;i++)
            printf("%c%d",vett[i],vett_occorrenze[i]);

        //porto i valori su vettore, altrimenti non posso passarli tramite fwrite

        for(int i=0,j=0;i<dimensione*2;i=i+2,j++) //DEVI SCRIVERE i=i+2, non solo i+2!
        {
            stringa_finale[i]=vett[j];
            stringa_finale[i+1]=vett_occorrenze[j]+'0';
        }

		fpOUT=fopen("output.bin","w");

		if(fpOUT!=NULL)
		{
			fwrite(stringa_finale,sizeof(char),dimensione*2,fpOUT);
			fclose(fpOUT);
		}
		else
			printf("File \"output.bin\" non creato correttamente...\n");
    }
    else
        printf("File \"input.txt\" non trovato o impossibile da aprire...\n");
}

int occorrenze_caratteri(char matrice[][DIM],int colonne,int riga_fissata,char carattere_cercato)
{
    int cont=0;

    for(int i=0;i<colonne;i++)
        if(matrice[riga_fissata][i]==carattere_cercato)
            cont++;
    return cont;
}

void Bubble_sort(char vett[],int vett_occorrenze[],int dimensione)
{
    int tmpI;
    char tmpC;

    int k=dimensione-1;
    int scambio=1;

    while(k>0 && scambio==1)
    {
        scambio=0;

        for(int i=0;i<k;i++)
        {
            if(vett_occorrenze[i]<vett_occorrenze[i+1])
            {
                tmpI=vett[i]; //scambio numeri
                vett[i]=vett[i+1];
                vett[i+1]=tmpI;

                tmpC=vett_occorrenze[i]; //scambio numeri
                vett_occorrenze[i]=vett_occorrenze[i+1];
                vett_occorrenze[i+1]=tmpC;

                scambio=1;
            }
        }
        k--;
    }
}