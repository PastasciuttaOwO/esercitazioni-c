// Autore: Vincenzo Silvano - Traccia A, Turno 1

#include <stdio.h>

#define DIM 100

float prodotto_scalare(int matrice[][DIM],int riga,int vettore[],int colonna_analizzata);
void calcolo_media_max_min(float vettore[],int dimensione,float *media,float *max,float *min);

int main()
{
	int mat[DIM][DIM];
	int r,c; //numero righe e colonne

	int vett[DIM];
	float prodscal[DIM]; //vettore dei prodotti scalari tra vett e colonne

	float max, min;
	float media; //inizializzata nel sottoprogramma
	float buf[3]; //vettore per fwrite con i valori media (indice 0), max (indice 1), min(indice 2)

	FILE *fpIN;
	FILE *fpOUT;

	printf("Autore: Vincenzo Silvano - Traccia A, Turno 1\n\n");

	//lettura di numero righe, colonne e elementi matrice
	fpIN=fopen("input.txt","r");

	if(fpIN!=NULL)
	{
	    //N.B. quando tratto interi, posso mettere matrici formattate "bene" e non tutto in una riga, siccome
	    //fscanf si ferma al primo " ", non allo \n

		fscanf(fpIN,"%d%d",&r,&c); //lettura riga e colonna

		for(int i=0;i<r;i++)
            for(int j=0;j<c;j++)
                fscanf(fpIN,"%d",&mat[i][j]); //lettura elementi della matrice da file

        printf("La matrice letta da file ha %d righe e %d colonne ed e' la seguente:\n",r,c);
		for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
                printf("%5d",mat[i][j]);
            printf("\n");
        }

        for(int i=0;i<r;i++) //metto come limite r perch� altrimenti non avrebbe senso fare il prodotto scalare (siccome r � la dim delle colonne!)
            fscanf(fpIN,"%d",&vett[i]);

        fclose(fpIN);

        printf("\nIl vettore letto da file di dimensione %d e' il seguente:\n",r);
        for(int i=0;i<r;i++)
            printf("%5d",vett[i]);

        //Utilizzo il sottoprogramma per assegnare al vettore prodscal gli elementi float
        for(int i=0;i<c;i++)
            prodscal[i]=prodotto_scalare(mat,r,vett,i);

        printf("\n\nIl vettore dei prodotti scalari di dimensione %d e' il seguente:\n",c);
        for(int i=0;i<c;i++)
            printf("%10.2f",prodscal[i]); //attento a stampare con il %f i float!

        calcolo_media_max_min(prodscal,c,&media,&max,&min); //faccio un unico sottoprogramma per semplicit�

        printf("\n\nMedia: %.2f\nMassimo: %.2f\nMinimo: %.2f\n",media,max,min);

        //creazione e scrittura su file binario
        buf[0]=media;
        buf[1]=max;
        buf[2]=min;

        fpOUT=fopen("output.bin","w");
        fwrite(buf,sizeof(float),3,fpOUT);

        fclose(fpOUT);
	}
	else
		printf("Impossibile aprire il file \"input.txt\"...");
}

float prodotto_scalare(int matrice[][DIM],int riga,int vettore[],int colonna_analizzata)
{
    float result=0;

    for(int j=0;j<riga;j++)
        result+=matrice[j][colonna_analizzata]*vettore[j];

    return result;
}

void calcolo_media_max_min(float vettore[],int dimensione,float *media,float *max,float *min)
{
    *media=0;
    for(int i=0;i<dimensione;i++)
    {
        if(i==0)
        {
            *max=vettore[0];
            *min=vettore[0];
        }

        if(*max<vettore[i])
            *max=vettore[i];

        if(*min>vettore[i])
            *min=vettore[i];

        *media+=vettore[i];
    }

    *media/=dimensione;
}
